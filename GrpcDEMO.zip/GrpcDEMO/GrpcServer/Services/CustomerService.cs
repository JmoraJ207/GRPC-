﻿using Grpc.Core;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GrpcServer.Services
{
    public class CustomerService : Customer.CustomerBase
    {
        private readonly ILogger<CustomerService> logger;

        public CustomerService(ILogger<CustomerService> logger) {
            this.logger = logger;
        }

        public override Task<CustomerModel> GetCustomerInfo(CustomerLookupModel request, ServerCallContext context)
        {
            CustomerModel output = new CustomerModel();
           
            if (request.Message.Equals("Hello Word")) {

                output.Message = "Hello Word!!!";
            



            }
            else if (request.Id == 2)
            {
                output.Message = "Hello Word!!!";
                output.Who = request.Who ;
                Console.WriteLine("2");



            }
            else if (request.Id == 3)
            {
                output.Who = request.Who;
                output.Message = request.Message;


            }
            else
            {

            }
            return Task.FromResult(output);

        }
    }
}
